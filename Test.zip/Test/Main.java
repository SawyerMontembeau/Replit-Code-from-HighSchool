import java.util.*;
class Main {
  public static void main(String[] args) {

    int numbers[] = new int[20];
for(int i = 0,x = 2; i <=19; i++,x+=2 ){	
 numbers[i] = x;
	
System.out.println("Number " + numbers[i] +", "); 
}

    
  

  }
}